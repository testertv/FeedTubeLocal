const feeds = [
  {
    "ChannelName": "Veritasium",
    "ChannelID": "https://www.youtube.com/feeds/videos.xml?channel_id=UCHnyfMqiRRG1u-2MsSQLbXA"
  },
  {
    "ChannelName": "Numberphile",
    "ChannelID": "https://www.youtube.com/feeds/videos.xml?channel_id=UCoxcjq-8xIDTYp3uz647V5A"
  }
];